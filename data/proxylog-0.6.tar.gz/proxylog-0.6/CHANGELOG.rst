=========
ChangeLog
=========


v0.6
====

* Added "--version" program option


v0.5
====

* Added more aggressive XML formatifying
* Cleaned up verbose output to use logging subsystem


v0.4
====

* Moved to YAML-based I/O logging (dropped pickle and CSV)
* Added Pygments colorization support
* Renamed "--prettify" to "--format"
* Added YAML and JSON format prettification


v0.3.0
======

* Extracted proxylog out of utools and ported to GitHub
